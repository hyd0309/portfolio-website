---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: 326e0626bbd7614917931fd2456c8961_7a4d5c41daa711f1a0ca525400de85a5
    ReservedCode1: eHWhY0aaULQnM8oM6wx9syW22h/YfbO/DtQ3uMIwsfn7rXpQ7z6ucU68cUlRFpkuzOsghFMbH3KtJQiDgyaGbNTqo0WGDeNBMq7FVdim3EWGF4/jbHx5ySw8a10E9Gl8/iTxiHYG0PwZWmnSrnwFjhiR3RSrJbxogh+R+lZgJbraLJaU7gK4Wfx7IFo=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: 326e0626bbd7614917931fd2456c8961_7a4d5c41daa711f1a0ca525400de85a5
    ReservedCode2: eHWhY0aaULQnM8oM6wx9syW22h/YfbO/DtQ3uMIwsfn7rXpQ7z6ucU68cUlRFpkuzOsghFMbH3KtJQiDgyaGbNTqo0WGDeNBMq7FVdim3EWGF4/jbHx5ySw8a10E9Gl8/iTxiHYG0PwZWmnSrnwFjhiR3RSrJbxogh+R+lZgJbraLJaU7gK4Wfx7IFo=
---

# Cymatics C86V 页面监控脚本

## 功能概述

本脚本用于持续监控 Cymatics C86V 直播页面，自动检测并点击页面中出现的 "Add to Cart"（添加到购物车）按钮，并在 7 小时监控结束后自动完成购物车结算流程。

## 核心功能

### 1. 连接真实 Firefox 浏览器

- 通过 Marionette 协议连接用户已打开的 Firefox 实例，保留登录状态和 Cookie
- 不启动隔离浏览器，确保使用用户的真实账号环境
- 通过 geckodriver 桥接实现 Selenium 与 Firefox 的通信

### 2. 精准识别目标区域

- **锚点定位**：以页面中 "Limited Time Free Packs, Plugins & Special Deals Will Unlock Below" 字样为基准，定位其下方的唯一 `div.dl-card-grid` 卡片网格
- **排除干扰**：顶部 banner 区域（`.dl-offer-banner`）也包含 "Add to Cart" 文本，脚本通过锚点方式完全排除这些干扰元素
- **按钮识别**：只识别目标卡片网格内文本为 "Add to Cart" 的 `button.btn.download-btn.dl-card__cta` 按钮

### 3. 自动化操作流程

#### 小循环（每轮检查）

1. 查找目标卡片网格中的 "Add to Cart" 按钮
2. 找到后自动点击
3. 等待 5 秒让购物车弹窗出现
4. 点击屏幕中央关闭弹窗
5. 立即重新检查，直到当前页面无更多 "Add to Cart" 为止

#### 大循环（轮询）

- 每 4 分钟执行一次小循环
- 共运行 7 小时
- 每次检查前打印轮次信息，方便实时查看进度

#### 结算流程（7 小时后）

1. 刷新页面确保连接正常
2. 点击右上角购物车图标
3. 在购物车页面点击 "Checkout Now" 按钮
4. 在结账页面点击 "Complete Order" 按钮
5. 完成后保持浏览器窗口打开，等待用户手动操作或超时退出

## 技术细节

| 配置项 | 值 | 说明 |
|--------|-----|------|
| 监控时长 | 7 小时 | 可修改 `MONITOR_DURATION_HOURS` |
| 轮询间隔 | 4 分钟 (240 秒) | 可修改 `POLL_INTERVAL_SECONDS` |
| Marionette 端口 | 2828 | Firefox 远程调试端口 |
| Geckodriver 端口 | 4444 | Selenium WebDriver 桥接端口 |
| 页面加载策略 | eager | DOM 就绪即返回，不等资源加载完 |
| 超时退出 | 4 小时 | 监控结束后等待 Enter 的最长时间 |

## 启动方式

```bash
# 方法一：双击启动器
run_monitor.bat

# 方法二：命令行直接运行
set PYTHONPATH=C:\Users\87197\.marvis_pylib
E:\Tools\miniconda3\python.exe monitor_cymatics.py
```

## 前置条件

1. **Firefox 以 Marionette 模式启动**：
   ```
   firefox --marionette --marionette-port 2828
   ```
2. **Selenium 依赖**：安装到固定目录 `C:\Users\87197\.marvis_pylib`，不随 Marvis 更新丢失
3. **Geckodriver**：与脚本同目录放置 `geckodriver.exe`
4. **Python 环境**：使用 Miniconda Python（`E:\Tools\miniconda3\python.exe`），设置 PYTHONPATH

## 注意事项

- 运行期间电脑不能休眠
- 脚本会弹出控制台窗口显示日志，便于实时监控
- 首次运行时需手动启动 Firefox Marionette 实例
- 旧版 geckodriver 残留会占用端口，需先杀掉再重启
- 脚本末尾按 Enter 可提前断开连接，超时 4 小时后自动断开
*（内容由AI生成，仅供参考）*
